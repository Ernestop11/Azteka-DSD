import defaultTheme from 'tailwindcss/defaultTheme';

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Inter"', ...defaultTheme.fontFamily.sans],
        display: ['"Space Grotesk"', ...defaultTheme.fontFamily.sans],
      },
      colors: {
        surface: {
          DEFAULT: '#0F172A',
          soft: '#111C33',
          muted: '#1E293B',
        },
        accent: {
          emerald: '#10B981',
          blue: '#2563EB',
          violet: '#7C3AED',
        },
        glow: {
          teal: 'rgba(45, 212, 191, 0.35)',
          blue: 'rgba(59, 130, 246, 0.4)',
        },
      },
      backgroundImage: {
        'bolt-radial': 'radial-gradient(125% 125% at 50% 0%, rgba(15, 23, 42, 1) 0%, rgba(2, 6, 23, 1) 55%, rgba(0, 0, 0, 1) 100%)',
        'bolt-grid': 'linear-gradient(to right, rgba(148, 163, 184, 0.07) 1px, transparent 1px), linear-gradient(to bottom, rgba(148, 163, 184, 0.07) 1px, transparent 1px)',
        'bolt-card': 'linear-gradient(135deg, rgba(20, 184, 166, 0.18), rgba(59, 130, 246, 0.18))',
        'bolt-accent': 'linear-gradient(90deg, #7C3AED 0%, #2563EB 100%)',
      },
      backgroundSize: {
        grid: '40px 40px',
      },
      boxShadow: {
        'bolt-card': '0 20px 45px -25px rgba(15, 118, 110, 0.45)',
        'bolt-ring': '0 0 40px -5px rgba(59, 130, 246, 0.45)',
        'bolt-violet': '0 0 35px -5px rgba(124, 58, 237, 0.5)',
      },
      dropShadow: {
        'bolt-glow': ['0 10px 20px rgba(14, 165, 233, 0.45)', '0 5px 10px rgba(56, 189, 248, 0.35)'],
      },
      animation: {
        blob: 'blob 7s infinite',
        float: 'float 3s ease-in-out infinite',
        'fade-up': 'fadeInUp 0.6s ease-out forwards',
        'slide-left': 'slideInLeft 0.6s ease-out forwards',
        'slide-right': 'slideInRight 0.6s ease-out forwards',
        'scale-in': 'scaleIn 0.5s ease-out forwards',
      },
    },
  },
  plugins: [],
};
