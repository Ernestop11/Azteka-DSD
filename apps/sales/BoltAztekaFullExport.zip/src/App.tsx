import React, { useEffect, useState } from "react";
import Hero from "./components/Hero";
import CatalogGrid from "./components/CatalogGrid";
import SpecialOffers from "./components/SpecialOffers";
import ProductBillboard from "./components/ProductBillboard";
import BundleShowcase from "./components/BundleShowcase";
import SuperAdminDashboard from "./pages/admin";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4102";

export default function App() {
  const [products, setProducts] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  // quick /admin route check
  if (typeof window !== "undefined" && window.location.pathname.startsWith("/admin")) {
    return <SuperAdminDashboard />;
  }

  useEffect(() => {
    fetch(`${API_URL}/api/products`)
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setProducts(data);
        else if (data.products) setProducts(data.products);
        else setError("Unexpected API shape");
      })
      .catch(() => setError("Failed to load products"));
  }, []);

  return (
    <main className="p-6 font-sans bg-gray-50 min-h-screen">
      <h1 className="text-3xl font-bold mb-4 text-emerald-700">
        🌮 Azteka DSD Product Catalog
      </h1>

      {error && <p className="text-red-600">{error}</p>}

      {!error && products.length === 0 && (
        <p className="text-gray-600">Loading products…</p>
      )}

      {products.length > 0 && (
        <>
          <SpecialOffers offers={[]} />
          <BundleShowcase bundles={[]} onSelectBundle={() => {}} />
          <ProductBillboard
            products={products.slice(0, 4)}
            title="Featured Products"
            subtitle="Live from your backend API"
            onAddToCart={() => {}}
          />
          <CatalogGrid
            products={products}
            brands={[]}
            categories={[]}
            onAddToCart={() => {}}
            onQuickView={() => {}}
          />
        </>
      )}
    </main>
  );
}

